
# name = ''
# student ID = ''

import doctest
import datetime
import random
from room import Room, MONTHS, DAYS_PER_MONTH


class Reservation:
    booking_numbers = []

    def __init__(self, name: str, room: Room, check_in: datetime.date, check_out: datetime.date,
                 booking_number=None):
        """
            >>> random.seed(987)
            >>> Reservation.booking_numbers = []
            >>> r1 = Room("Queen", 105, 80.0)
            >>> r1.set_up_room_availability(['May'], 2021)
            >>> date1 = datetime.date(2021, 5, 3)
            >>> date2 = datetime.date(2021, 5, 10)
            >>> my_reservation = Reservation('Mrs. Santos', r1, date1, date2)
            >>> print(my_reservation.check_in)
            2021-05-03
            >>> print(my_reservation.check_out)
            2021-05-10
            >>> my_reservation.booking_number
            1953400675629
            >>> r1.availability[(2021, 5)][9]
            False
        """
        # check input
        if not room.is_available(check_in, check_out):
            raise AssertionError("The input room is not available at the specified dates")
        if booking_number:
            if booking_number in self.booking_numbers or type(booking_number) != int \
                    or booking_number < 0 or len(str(booking_number)) != 13:
                raise AssertionError("booking number is invalid")

        self.name = name
        self.room_reserved = room
        self.check_in = check_in
        self.check_out = check_out
        if not booking_number:
            booking_number = random.randint(1000000000000, 9999999999999)
            while booking_number in self.booking_numbers:
                booking_number = random.randint(1000000000000, 9999999999999)
        self.booking_number = booking_number
        self.booking_numbers.append(booking_number)

        while check_in < check_out:
            self.room_reserved.reserve_room(check_in)
            check_in += datetime.timedelta(days=1)

    def __str__(self):
        """
            >>> random.seed(987)
            >>> Reservation.booking_numbers = []
            >>> r1 = Room("Queen", 105, 80.0)
            >>> r1.set_up_room_availability(['May'], 2021)
            >>> date1 = datetime.date(2021, 5, 3)
            >>> date2 = datetime.date(2021, 5, 10)
            >>> my_reservation = Reservation('Mrs. Santos', r1, date1, date2)
            >>> print(my_reservation)
            Booking number: 1953400675629
            Name: Mrs. Santos
            Room reserved: Room 105,Queen,80.0
            Check-in date: 2021-05-03
            Check-out date: 2021-05-10
        """
        return "Booking number: %s\n" \
               "Name: %s\n" \
               "Room reserved: %s\n" \
               "Check-in date: %s\n" \
               "Check-out date: %s" % (str(self.booking_number), self.name, str(self.room_reserved),
                                       str(self.check_in), str(self.check_out))

    def to_short_string(self):
        """
            >>> random.seed(987)
            >>> Reservation.booking_numbers = []
            >>> r1 = Room("Queen", 105, 80.0)
            >>> r1.set_up_room_availability(['May'], 2021)
            >>> date1 = datetime.date(2021, 5, 3)
            >>> date2 = datetime.date(2021, 5, 10)
            >>> my_reservation = Reservation('Mrs. Santos', r1, date1, date2)
            >>> my_reservation.to_short_string()
            '1953400675629--Mrs. Santos'
        """
        return "%s--%s" % (str(self.booking_number), self.name)

    @classmethod
    def from_short_string(cls, short_string: str, check_in: datetime.date, check_out: datetime.date,
                          room: Room):
        """
            >>> Reservation.booking_numbers = []
            >>> r1 = Room("Queen", 105, 80.0)
            >>> r1.set_up_room_availability(['May'], 2021)
            >>> date1 = datetime.date(2021, 5, 3)
            >>> date2 = datetime.date(2021, 5, 4)
            >>> my_reservation = Reservation.from_short_string('1953400675629--Mrs. Santos', date1, date2, r1)
            >>> print(my_reservation.check_in)
            2021-05-03
            >>> print(my_reservation.check_out)
            2021-05-04
            >>> my_reservation.booking_number
            1953400675629
            >>> r1.availability[(2021, 5)][3]
            False
        """
        booking_number = short_string.split("--")[0]
        name = short_string.split("--")[1]
        return cls(name, room, check_in, check_out, int(booking_number))

    @staticmethod
    def get_reservations_from_row(room: Room, rsv_list: list):
        """
            >>> random.seed(987)
            >>> Reservation.booking_numbers = [] # needs to be reset for the test below to pass
            >>> r1 = Room("Queen", 105, 80.0)
            >>> r1.set_up_room_availability(MONTHS, 2021)
            >>> rsv_strs = [(2021, 'May', 3, '1953400675629--Jack'), (2021, 'May', 4, '1953400675629--Jack')]
            >>> rsv_dict = Reservation.get_reservations_from_row(r1, rsv_strs)
            >>> print(rsv_dict[1953400675629])
            Booking number: 1953400675629
            Name: Jack
            Room reserved: Room 105,Queen,80.0
            Check-in date: 2021-05-03
            Check-out date: 2021-05-05
        """
        check_in_dict = {}
        check_out_dict = {}
        for i in rsv_list:
            booking_number = int(i[3].split('--')[0])
            date_tmp = datetime.date(i[0], MONTHS.index(i[1])+1, i[2])
            if booking_number not in check_in_dict:
                check_in_dict[booking_number] = date_tmp
            elif date_tmp < check_in_dict[booking_number]:
                check_in_dict[booking_number] = date_tmp

            if booking_number not in check_out_dict:
                check_out_dict[booking_number] = date_tmp
            elif date_tmp > check_out_dict[booking_number]:
                check_out_dict[booking_number] = date_tmp

        rsv_dict = {}
        for i in rsv_list:
            booking_number = int(i[3].split('--')[0])
            if booking_number not in rsv_dict:
                rsv_dict[booking_number] = Reservation.from_short_string(i[3],
                                                                         check_in_dict[booking_number],
                                                                         check_out_dict[booking_number]
                                                                         + datetime.timedelta(days=1),
                                                                         room)
        return rsv_dict


if __name__ == '__main__':
    doctest.testmod(verbose=False)
