# name = ''
# student ID = ''

import doctest
import datetime
import random
import matplotlib
import os
from hotel import Hotel


class Booking:

    def __init__(self, hotels: list):
        self.hotels = hotels

    @classmethod
    def load_system(cls):
        '''
            >>> system = Booking.load_system()
            >>> len(system.hotels)
            2
            >>> system.hotels[0].name
            'The Great Northern Hotel'
            >>> print(system.hotels[0].rooms[314])
            Room 315,Queen,129.99
        '''
        path = 'hotels'
        hotels = list()
        for dir_name in os.listdir(path)[::-1]:
            hotels.append(Hotel.load_hotel(dir_name))
        return cls(hotels)

    def menu(self):
        print("Welcome to Booking System")
        print("What would you like to do?")
        print("1 Make a reservation")
        print("2 Cancel a reservation")
        print("3 Look up a reservation")
        user_input = input("> ")
        if user_input == '1':
            self.create_reservation()
        elif user_input == '2':
            self.cancel_reservation()
        elif user_input == '3':
            self.lookup_reservation()
        else:
            self.delete_reservations_at_random()

        for hotel in self.hotels:
            hotel.save_hotel()

    def create_reservation(self):
        name = input("Please enter your name: ")
        print("Hi %s! Which hotel would you like to book?" % name)

        hotel_dict = {}
        for index, hotel in enumerate(self.hotels):
            print("%s %s" % (str(index+1), hotel.name))
            hotel_dict[index + 1] = hotel
        selected_num = int(input("> "))
        selected_hotel = hotel_dict[selected_num]

        print("Which type of room would you like?")
        type_dict = {}
        types = selected_hotel.get_available_room_types()
        for index, _type in enumerate(types):
            print("%s %s" % (str(index+1), _type))
            type_dict[index + 1] = _type
        selected_num = int(input("> "))
        selected_type = type_dict[selected_num]

        check_in_str = input("Enter check-in date (YYYY-MM-DD): ")
        check_out_str = input("Enter check-out date (YYYY-MM-DD): ")
        check_in = datetime.date(int(check_in_str.split('-')[0]),
                                 int(check_in_str.split('-')[1]),
                                 int(check_in_str.split('-')[2]))

        check_out = datetime.date(int(check_out_str.split('-')[0]),
                                  int(check_out_str.split('-')[1]),
                                  int(check_out_str.split('-')[2]))
        booking_number = selected_hotel.make_reservation(name, selected_type, check_in, check_out)
        receipt = round(selected_hotel.get_receipt([booking_number]), 2)
        print("Ok. Making your reservation for a %s room." % selected_type)
        print("Your reservation number is: %s" % str(booking_number))
        print("Your total amount due is: $%s" % str(receipt))
        print("Thank you!")

    def cancel_reservation(self):
        booking_number = int(input("Please enter your booking number: "))
        for hotel in self.hotels:
            if booking_number in hotel.reservations:
                hotel.cancel_reservation(booking_number)
                print('Cancelled successfully.')
                return
        print('Could not find a reservation with that booking number.')

    def lookup_reservation(self):
        is_have = input("Do you have your booking number(s)? ")
        if is_have == 'yes':
            booking_numbers = []
            input_number = input("Please enter a booking number (or 'end'): ")
            while input_number != "end":
                booking_numbers.append(int(input_number))
                input_number = input("Please enter a booking number (or 'end'): ")

            for booking_number in booking_numbers:
                for hotel in self.hotels:
                    if booking_number in hotel.reservations:
                        print("Reservation found at hotel %s: " % hotel.name)
                        print(hotel.reservations[booking_number])
                        receipt = round(hotel.get_receipt([booking_number]), 2)
                        print("Total amount due: $%s" % str(receipt))
                        print()
        elif is_have == 'no':
            name = input("Please enter your name: ")
            hotel_name = input("Please enter the hotel you are booked at: ")
            room_number = int(input("Enter the reserved room number: "))
            check_in_str = input("Enter the check-in date (YYYY-MM-DD): ")
            check_out_str = input("Enter the check-out date (YYYY-MM-DD): ")
            check_in = datetime.date(int(check_in_str.split('-')[0]),
                                     int(check_in_str.split('-')[1]),
                                     int(check_in_str.split('-')[2]))

            check_out = datetime.date(int(check_out_str.split('-')[0]),
                                      int(check_out_str.split('-')[1]),
                                      int(check_out_str.split('-')[2]))
            for hotel in self.hotels:
                if hotel.name != hotel_name:
                    continue

                for booking_number, rsv in hotel.reservations.items():
                    if rsv.name == name and rsv.room_reserved.room_num == room_number and \
                            rsv.check_in == check_in and rsv.check_out == check_out:
                        print("Reservation found under booking number %s." % str(booking_number))
                        print("Here are the details: ")
                        print(hotel.reservations[booking_number])
                        receipt = round(hotel.get_receipt([booking_number]), 2)
                        print("Total amount due: $%s" % str(receipt))
                        print()

    def delete_reservations_at_random(self):
        print("You said the magic word!")
        del_index = random.randint(0, len(self.hotels) - 1)
        hotel = self.hotels[del_index]
        booking_numbers = [booking_number for booking_number in hotel.reservations]
        for booking_number in booking_numbers:
            hotel.cancel_reservation(booking_number)


if __name__ == '__main__':
    # doctest.testmod(verbose=False, optionflags=doctest.NORMALIZE_WHITESPACE)

    # 2. test menu()
    booking = Booking.load_system()
    booking.menu()

    # 3. test create_reservation()
    # random.seed(137)
    # booking = Booking.load_system()
    # booking.create_reservation()

    # 4. test cancel_reservation()
    # booking = Booking.load_system()
    # booking.cancel_reservation()
    # booking.cancel_reservation()

    # 5. test lookup_reservation()
    # booking = Booking.load_system()
    # booking.lookup_reservation()
    # booking.lookup_reservation()

    # 6. test
    # random.seed(1338)
    # booking = Booking.load_system()
    # booking.delete_reservations_at_random()
    # print(len(booking.hotels[1].reservations))
    # print(len(booking.hotels[0].reservations))
