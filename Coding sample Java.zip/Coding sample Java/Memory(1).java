import java.util.LinkedList;

public class Memory {
    class StringInterval {
        public int id;
        public int start;
        public int length;

        StringInterval (int id, int start, int length) {
            this.id = id;
            this.start = start;
            this.length = length;
        }
    }

    public LinkedList<StringInterval> intervalList;
    public char[] memoryArray;
    public static int idCount;

    Memory (int length) {
        memoryArray = new char[length];
        intervalList = new LinkedList<>();
        idCount = 0;
    }

    public String get(int id) {
        for (StringInterval interval : intervalList) {
            if (id == interval.id) {
                StringBuilder ret = new StringBuilder();
                for (int i = 0; i < interval.length; i++) {
                    ret.append(memoryArray[interval.start + i]);
                }
                return ret.toString();
            }
        }
        return null;
    }

    public int get(String s) {
        for (StringInterval interval : intervalList) {
            if (interval.length == s.length()) {
                boolean equal = true;
                for (int i = 0; i < interval.length; i++) {
                    if (s.charAt(i) != memoryArray[interval.start + i]) {
                        equal = false;
                        break;
                    }
                }
                if (equal) {
                    return interval.id;
                }
            }
        }
        return -1;
    }

    public String remove(int id) {
        String ret = get(id);
        if (ret != null) {
            for (StringInterval interval : intervalList) {
                if (id == interval.id) {
                    intervalList.remove(interval);
                    return ret;
                }
            }
        }
        return null;
    }

    public int remove(String s) {
        int id = get(s);
        if (id != -1) {
            for (StringInterval interval : intervalList) {
                if (id == interval.id) {
                    intervalList.remove(interval);
                    return id;
                }
            }
        }
        return -1;
    }

    public int put(String s) {
        int id = idCount;

        boolean added = false;
        // find gap
        for (int i = 1; i < intervalList.size(); i++) {
            StringInterval prev = intervalList.get(i-1);
            StringInterval cur = intervalList.get(i);
            if (cur.start - prev.start - prev.length >= s.length()) {
                StringInterval interval = new StringInterval(id, prev.start + 
                        prev.length, s.length());
                intervalList.add(i, interval);
                int startIdx = prev.start + prev.length;
                for (int j = 0; j < s.length(); j++) {
                    memoryArray[startIdx + j] = s.charAt(j);
                }
                added = true;
                break;
            }
        }
        if (!added) {
            int startIdx;
            if (intervalList.isEmpty()) {
                startIdx = 0;
            } else {
                // not empty
                StringInterval last = intervalList.getLast();
                if (last.start + last.length + s.length() > memoryArray.length) {
                    defragment();
                }
                if (last.start + last.length + s.length() > memoryArray.length) {
                    return -1;
                }
                startIdx = last.start + last.length;
            }
            StringInterval newInterval = new StringInterval(id, startIdx, s.length());
            intervalList.addLast(newInterval);
            for (int i = 0; i < s.length(); i++) {
                memoryArray[startIdx + i] = s.charAt(i);
            }
        }
        idCount ++;
        return id;
    }

    public void defragment() {
        int previousIndex = 0;
        for (StringInterval interval : intervalList) {
            if (interval.start != previousIndex) {
                for (int i = 0; i < interval.length; i++) {
                    memoryArray[previousIndex + i] = memoryArray[interval.start + i];
                }
                interval.start = previousIndex;

            }
            previousIndex = interval.start + interval.length;
        }
    }

    public static void main(String[] args) {
//        Memory memory = new Memory(22);
//        memory.put("if");
//        memory.put("hello");
//        memory.put("and");
//        memory.put("goodbye");
//        System.out.println(memory.get(0));
//        System.out.println(memory.get(1));
//        System.out.println(memory.get(2));
//        System.out.println(memory.get(3));
//        System.out.println(memory.get("hello"));
//        System.out.println(memory.get("and"));
//        memory.remove(0);
//        memory.remove(2);
//        System.out.println(memory.intervalList.get(0).id+":"+ memory.intervalList.get(0).start);
//        System.out.println(memory.intervalList.get(1).id+":"+ memory.intervalList.get(1).start);
//

        Memory memory1 = new Memory(24);
        memory1.put("kiwi");
        memory1.put("pomegranate");
        memory1.put("apple");
        memory1.remove(1);
        memory1.put("grape");
        memory1.put("fig");
        memory1.put("pear");
        for (StringInterval interval : memory1.intervalList) {
            System.out.println(interval.id);
        }
        for (char c : memory1.memoryArray) {
            System.out.println(c);
        }
    }
}
