// add your imports here

class TSTNode<T extends Comparable<T>>{
    T element;     	            // The data in the node
    TSTNode<T>  left;   		// left child
    TSTNode<T>  mid;   		    // middle child
    TSTNode<T>  right;  		// right child

    // TODO: implement the node class here
    
    TSTNode(T element){
        this.element = element;
        left = null;
        mid = null;
        right = null;
    }

    TSTNode<T> findMax(){
        if (right == null) {
            return this;
        }
        return right.findMax();
    }

    TSTNode<T> findMin(){
        if (left == null) {
            return this;
        }
        return left.findMin();
    }

    int height(){
        if (left == null && mid == null && right == null) {
            return 0;
        } else {
            int leftHeight = -1, midHeight = -1, rightHeight = -1;
            if (left != null) {
                leftHeight = left.height();
            }
            if (mid != null) {
                midHeight = mid.height();
            }
            if (right != null) {
                rightHeight = right.height();
            }
            int h = Math.max(Math.max(leftHeight, midHeight), rightHeight);
            return 1 + h;
        }
    }

    // add your own helper methods if necessary
}